# assessmentmobilerobots_2022

Files for Assessment III PDE3432

Note: Everything is still in development, do not use as of yet!

To launch robot in empty world use: roslaunch assessmentmobilerobots_2022 assessment_world_empty_personalrobot.launch
To launch robot in world with boxes for navigation use: roslaunch assessmentmobilerobots_2022 assessment_world_boxes_personalrobot.launch


Directory explanation:
- demo: folder which contains videos/photos of development
- useful_commands: folder which containts txt files with useful ROS commands
